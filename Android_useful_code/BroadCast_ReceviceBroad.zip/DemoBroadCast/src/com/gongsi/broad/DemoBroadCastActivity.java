package com.gongsi.broad;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class DemoBroadCastActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
   /*发送广播，其他程序接收，并提示消息*/ 
    public void sendBroad1(View view){
    	Intent intent = new Intent();
    	intent.setAction("com.gongsi.borad1");
    	intent.putExtra("name", "zhangsan1");
    	intent.putExtra("sex", "Male");
    	sendBroadcast(intent);
    }
    /*发送广播，让其他程序接收，并打开一个新的Activity*/
    public void sendBroad2(View view){
    	Intent intent = new Intent();
    	intent.setAction("com.gongsi.borad2");
    	intent.putExtra("name", "lisi2");
    	intent.putExtra("sex", "Female");
    	sendBroadcast(intent);
    }
    
    /*动态的广播发送，并自己定义BroadcastReceiver匿名实现*/
    public void sendBroad3(View view){
    	IntentFilter filter = new IntentFilter();
    	filter.addAction("com.gongsi.borad3");
    	registerReceiver(receiver, filter);
    	
    	Intent intent = new Intent();
    	intent.setAction("com.gongsi.borad3");
    	intent.putExtra("name", "wangwu3");
    	intent.putExtra("sex", "Female");
    	sendBroadcast(intent);
    }
    
    private BroadcastReceiver receiver = new BroadcastReceiver() {
		
		@Override
		public void onReceive(Context context, Intent intent) {
			// TODO Auto-generated method stub
			Log.i("info", "动态的接收广播");
			Bundle bundle = intent.getExtras();
			Object[] keys = bundle.keySet().toArray();
			for(int i=0; i<keys.length; i++){
				Log.i("info", keys[i].toString() + ":" + bundle.get(keys[i].toString()));
			}
			Log.i("info", "end 动态广播接收");
		}
	};
}

















