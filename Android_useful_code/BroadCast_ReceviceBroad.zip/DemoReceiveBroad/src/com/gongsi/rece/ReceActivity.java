package com.gongsi.rece;


import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
/*需要在mainfest中注册为第一启动*/
public class ReceActivity extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		String action = intent.getAction();
		if (action.equals("com.gongsi.borad1")) {
			/*接收到广播，手机上发出提示条*/
			Notification noti = new Notification(R.drawable.icon, "标题提示",
					System.currentTimeMillis());
			noti.defaults = Notification.DEFAULT_SOUND;
			noti.flags = Notification.FLAG_AUTO_CANCEL;
			Intent it = new Intent(context, DemoReceiveBroadActivity.class);
			it.putExtras(intent);
			/*发送一个消息提示*/
			PendingIntent pi = PendingIntent.getActivity(context, 0, it,
					PendingIntent.FLAG_UPDATE_CURRENT);
			noti.setLatestEventInfo(context, "标题名称", "正文内容全部的信息主体", pi);
			NotificationManager manager = (NotificationManager) context
					.getSystemService(context.NOTIFICATION_SERVICE);
			manager.notify(100, noti);/* 100自定义编号，删除时方便 */
		} else if (action.equals("com.gongsi.borad2")) {
			Intent it = new Intent(context, MyServer.class);
			it.putExtras(intent);
			context.startService(it);
		} else if (action.equals("com.gongsi.borad3")){
			Log.i("info", "另一个程序接收动态广播");
			Bundle bundle = intent.getExtras();
			Object[] keys = bundle.keySet().toArray();
			for (int i=0; i<keys.length; i++){
				Log.i("info", keys[i].toString()+":"+bundle.get(keys[i].toString()));
			}
			Log.i("info","其他程序的动态广播接收完成");
		} else {
		}
	}
}
