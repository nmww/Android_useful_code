package com.gongsi.rece;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;
/*需要在mainfest中注册<service android:name=".MyServer"></service*/
public class MyServer extends Service {
	
	Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			stopSelf();
		}
		
	};

	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		Log.i("info", "service.onCreate");
	}

	@Override
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);
		Log.i("info", "service.startId");
		Bundle bundle = intent.getExtras();
		Object[] keys = bundle.keySet().toArray();
		for (int i=0; i<keys.length; i++){
			Log.i("info", keys[i].toString() + ":" + bundle.get(keys[i].toString()));
		}
		/*服务开启之后10s，通过handler给ui主线程发送一个空消息，让其停驶自己service*/
		new Thread(){

			@Override
			public void run() {
				// TODO Auto-generated method stub
				for (int i = 1; i<10; i++){
					try {
						sleep(1000);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				handler.sendEmptyMessage(0);
			}
			
		}.start();
		
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.i("info", "service.Destroy");
	}

}
