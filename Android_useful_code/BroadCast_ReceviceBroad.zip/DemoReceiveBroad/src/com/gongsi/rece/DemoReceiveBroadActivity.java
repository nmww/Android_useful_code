package com.gongsi.rece;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class DemoReceiveBroadActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        /*接收到广播，该窗口打开，并取出其中的键值对，显示在自定义的xml视图中*/
        TextView key1 = (TextView)findViewById(R.id.tvFirstKey);
        TextView value1 = (TextView)findViewById(R.id.tvFirstValue);
        TextView key2 = (TextView)findViewById(R.id.tvSecondKey);
        TextView value2 = (TextView)findViewById(R.id.tvSecondValue);
        
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        Object[] keys = bundle.keySet().toArray();
        key1.setText(keys[0].toString());
        value1.setText(bundle.get(keys[0].toString()).toString());
        key2.setText(keys[1].toString());
        value2.setText(bundle.get(keys[1].toString()).toString());

    }
}