package com.bmia;




import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class BMIAActivity extends Activity {
    /** Called when the activity is first created. */
	private EditText etWeight, etHeight;
	private Button butCalc;
	private static final int EXIT=1, RESET=2; 
	
	private void findViews(){
		etWeight=(EditText)findViewById(R.id.etWeight);
		etHeight=(EditText)findViewById(R.id.etHeight);
		butCalc=(Button)findViewById(R.id.butCalc);
	}
	
	
	
    @Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
    	menu.add(0, EXIT, 1, "EXIT");
    	menu.add(0, RESET, 2, "RESET");
		return super.onCreateOptionsMenu(menu);
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case EXIT:
			finish();
			break;
		case RESET:
			etWeight.setText("");
			etHeight.setText("");
			break;
		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}



	@Override
    public void onCreate(Bundle savedInstanceState) {
//		setTheme(R.style.fullscreen);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        findViews();
        addlistener();
    }
    private void addlistener(){
    	myclicklistener listener = new myclicklistener();
    	butCalc.setOnClickListener(listener);
    	etWeight.setOnClickListener(listener);
    	etHeight.setOnClickListener(listener);
    }
    
    private void calcbmi(){
    	
    	if (etWeight.getText()==null || etWeight.getText().toString().trim().equals("")){
			etWeight.setError(getText(R.string.err_w));
			return;
		}
		if (etHeight.getText()==null || etHeight.getText().toString().trim().equals("")){
			etHeight.setError(getText(R.string.err_h));
			return;
		}
		try {
			// TODO Auto-generated method stub
			double weight = Double.parseDouble(etWeight.getText().toString());
			double height = Double.parseDouble(etHeight.getText().toString());
			double bmi = weight*10000/height/height;
			if (bmi<18){
				Toast.makeText(BMIAActivity.this, getText(R.string.lev1), Toast.LENGTH_LONG).show();
			} else if(bmi<25 && bmi>=18){
				Toast.makeText(BMIAActivity.this, getText(R.string.lev2), Toast.LENGTH_LONG).show();
			} else if(bmi<30 && bmi>=25){
				Toast.makeText(BMIAActivity.this, getText(R.string.lev3), Toast.LENGTH_LONG).show();
			} else if(bmi<35 && bmi>=30){
				Toast.makeText(BMIAActivity.this, getText(R.string.lev4), Toast.LENGTH_LONG).show();
			} else if(bmi<35 && bmi>=40){
				Toast.makeText(BMIAActivity.this, getText(R.string.lev5), Toast.LENGTH_LONG).show();
			} else if(bmi<40 && bmi>=45){
				Toast.makeText(BMIAActivity.this, getText(R.string.lev6), Toast.LENGTH_LONG).show();
			} else{
				Toast.makeText(BMIAActivity.this, getText(R.string.lev7), Toast.LENGTH_LONG).show();
			}
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
				Toast.makeText(BMIAActivity.this, 
						R.string.edit_node, Toast.LENGTH_LONG).show();
			e.printStackTrace();
		}
    }
    
    class myclicklistener implements View.OnClickListener{
   
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.butCalc:
				calcbmi();
				break;
			case R.id.etWeight:
				if(etWeight.getText()!=null && etWeight.getText().toString().trim().equals(getText(R.string.input_w))){
					etWeight.setText("");
				}
				break;
			case R.id.etHeight:
				if(etHeight.getText()!=null && etHeight.getText().toString().trim().equals(getText(R.string.input_h))){
					etHeight.setText("");
				}
				break;

			default:
				break;
			}
	
		}
    	
    }
}