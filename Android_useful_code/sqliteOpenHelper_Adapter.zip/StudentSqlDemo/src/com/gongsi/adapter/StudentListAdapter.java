package com.gongsi.adapter;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.gongsi.entity.Student;
import com.gongsi.studentsql.R;

public class StudentListAdapter extends BaseAdapter {
	private ArrayList<Student> list;
	private LayoutInflater inflater;
	
	public StudentListAdapter(Context context, ArrayList<Student> list){
		this.inflater = LayoutInflater.from(context);
		this.list = list;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return list.get(position).getId();
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub
		ViewHolder holder = null;
		if(convertView == null){
			convertView = inflater.inflate(R.layout.stuitem, null);
			holder = new ViewHolder();
			holder.tvAge = (TextView)convertView.findViewById(R.id.tvAge);
			holder.tvId = (TextView)convertView.findViewById(R.id.tvId);
			holder.tvSex= (TextView)convertView.findViewById(R.id.tvSex);
			holder.tvName= (TextView)convertView.findViewById(R.id.tvName);
			convertView.setTag(holder);
		} else{
			holder = (ViewHolder)convertView.getTag();
		}
		Student stu = list.get(position);
		holder.tvAge.setText(String.valueOf(stu.getAge()));
		holder.tvId.setText(String.valueOf(stu.getId()));
		holder.tvName.setText(stu.getName());
		holder.tvSex.setText(stu.getSex());
		return convertView;
	}
	
	class ViewHolder{
		private TextView tvId;
		private TextView tvName;
		private TextView tvAge;
		private TextView tvSex;
		
	}

}
