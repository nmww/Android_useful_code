package com.gongsi.object;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.gongsi.entity.Student;

public class StudentDao {
	private DBOpenHelper helper;
	private SQLiteDatabase db;
	
	public StudentDao (Context context){
		helper = new DBOpenHelper(context);
	}
	
	public long addStudent(Student stu){
		long rowId = -1;
		if(stu!=null){
			ContentValues values = new ContentValues();
			values.put("sname", stu.getName());
			values.put("age", stu.getAge());
			values.put("sex", stu.getSex());
			db = helper.getReadableDatabase();
			rowId = db.insert("stutbl", null, values);
			db.close();
		}
		return rowId;
	}
	
	public int updateStudent(Student stu){
		int count = -1;
		if (stu != null){
			ContentValues values = new ContentValues();
			values.put("sname", stu.getName());
			values.put("age", stu.getAge());
			values.put("sex", stu.getSex());
			db = helper.getWritableDatabase();
			count = db.update("stutbl", values, "_id=?", 
					new String[]{String.valueOf(stu.getId())});
			db.close();
		}
		return count;
	}
	
	public int deleteStudent(int id){
		int count = -1;
		db = helper.getWritableDatabase();
		count = db.delete("stutbl", "_id=?", new String[]{String.valueOf(id)});
		db.close();
		
		return count;
	}
	
	public ArrayList<Student> search(){
		ArrayList<Student> list = null;
		String sql = "select * from stutbl";
		db = helper.getReadableDatabase();
		Cursor cursor = db.rawQuery(sql, null);
		if (cursor != null){
			list = new ArrayList<Student>();
			while(cursor.moveToNext()){
				Student stu = new Student();
				stu.setId(cursor.getInt(cursor.getColumnIndex("_id")));
				stu.setAge(cursor.getInt(cursor.getColumnIndex("age")));
				stu.setName(cursor.getString(cursor.getColumnIndex("sname")));
				stu.setSex(cursor.getString(cursor.getColumnIndex("sex")));
				
				list.add(stu);
			}
		}
		
		return list;
	}
	
	public void closeDB(){
		if(db != null && db.isOpen()){
			db.close();
			db=null;
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
