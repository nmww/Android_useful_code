package com.gongsi.object;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class DBOpenHelper extends SQLiteOpenHelper {
	private static final int VERSION = 1;
	private static final String DBNAME = "studb";

	public DBOpenHelper(Context context, String dbName, CursorFactory factory,
			int version) {
		super(context, dbName, factory, version);
	}

	public DBOpenHelper(Context context) {
		super(context, DBNAME, null, VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		// TODO Auto-generated method stub
		String sql = "create table if not exists stutbl" + "("
				+ "_id integer primary key autoincrement,"
				+ "sname text not null," + "age integer," + "sex text" + ")";
		db.execSQL(sql);
		db.execSQL("insert into stutbl (sname,sex,age) values('zhangsan','Male',19)");
		db.execSQL("insert into stutbl (sname, sex, age) " +
				"values('wangwu','FaMale',29)");
		db.execSQL("insert into stutbl (sname, sex, age) " +
				"values('chenliu','Male',34)");
		db.execSQL("insert into stutbl (sname, sex, age) " +
				"values('liuer','Male',42)");
	}
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
	}
}
