package com.gongsi.studentsql;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import com.gongsi.adapter.StudentListAdapter;
import com.gongsi.entity.Student;
import com.gongsi.object.StudentDao;

public class StudentSqlDemoActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        ListView lvStudent = (ListView)findViewById(R.id.lvStudent);
        StudentDao dao = new StudentDao(this);
        ArrayList<Student> list = dao.search();
        StudentListAdapter adapter = new StudentListAdapter(this, list);
        lvStudent.setAdapter(adapter);
    }
}