package com.zhg.test;
import javax.xml.parsers.SAXParserFactory;

import com.zhg.entity.Student;
import com.zhg.entity.StudentByName;
import com.zhg.util.MyArrays;


public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student[] s = new Student[5];
		s[0] = new Student(1,"zs",19);
		s[1] = new Student(3,"ww",27);
		s[2] = new Student(2,"cl",38);
		s[3] = new Student(5,"zk",18);
		s[4] = new Student(4,"ls",55);
		
		System.out.println("=========MyArrays.sort(s)==========");
		MyArrays.sort(s);
		
		for(Student stu : s){
			System.out.println(stu);
		}
		System.out.println("=========MyArrays.sort(s,new StudentByName)==========");
		MyArrays.sort(s,new StudentByName());
		
		for(Student stu : s){
			System.out.println(stu);
		}
		System.out.println(Thread.currentThread());
	}

}
