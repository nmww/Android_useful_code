package com.zhg.util;

import com.zhg.entity.Student;

public interface MyComparable<T>{
	int compareTo(T t);
}