package com.zhg.util;

public class MyArrays {
	public static void sort(Object[] obj){ 
		if(obj != null){
			MyComparable[] c = new MyComparable[obj.length];
			for(int i=0;i<obj.length;i++){
				c[i] = (MyComparable)obj[i];
			}
			
			for(int i=0;i<c.length-1;i++){
				for(int j=i+1;j<c.length;j++){
					if(c[i].compareTo(c[j])>0){
						MyComparable cm = c[i];
						c[i] = c[j];
						c[j] = cm;
					}
				}
			}
			for(int i=0;i<obj.length;i++){
				obj[i] = c[i];
			}
		}
	}
	public static void sort(Object[] obj,MyComparator comparator){ 
		if(obj != null){
			MyComparable[] c = new MyComparable[obj.length];
			for(int i=0;i<obj.length;i++){
				c[i] = (MyComparable)obj[i];
			}
			
			for(int i=0;i<c.length-1;i++){
				for(int j=i+1;j<c.length;j++){
					if(comparator.compare(c[i], c[j])>0){
						MyComparable cm = c[i];
						c[i] = c[j];
						c[j] = cm;
					}
				}
			}
			for(int i=0;i<obj.length;i++){
				obj[i] = c[i];
			}
		}
	}
}
