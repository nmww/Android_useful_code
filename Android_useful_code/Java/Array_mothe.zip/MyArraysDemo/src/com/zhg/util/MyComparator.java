package com.zhg.util;

import com.zhg.entity.Student;

public interface MyComparator<T> {
	int compare(T t1,T t2);
}
