package com.zhg.entity;
import com.zhg.util.MyComparator;


public class StudentByName implements MyComparator<Student> {

	@Override
	public int compare(Student stu1, Student stu2) {
		// TODO Auto-generated method stub
		return stu1.getName().compareTo(stu2.getName());
	}

}
