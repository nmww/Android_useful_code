package com.zhg.test;

import java.util.ArrayList;

import com.zhg.entity.Student;
import com.zhg.service.SAXService;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 	TODO Auto-generated method stub
		ArrayList<Student> list = new SAXService().getStudents("c:\\student.xml");
		for(Student stu : list){
			System.out.println(stu);
		}
	}

}
