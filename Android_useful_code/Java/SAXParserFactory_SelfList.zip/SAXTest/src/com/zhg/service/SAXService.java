package com.zhg.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.zhg.entity.Student;

public class SAXService {
	public ArrayList<Student> getStudents(String fileName){
		SAXParserFactory factory = null;
		SAXParser parser = null;
		MyHandler handler = new MyHandler();
		
		try {
			factory = SAXParserFactory.newInstance();
			parser = factory.newSAXParser();
			File file = new File(fileName);
			parser.parse(file,handler);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return handler.students;
		
	}
	
	private class MyHandler extends DefaultHandler{
		private ArrayList<Student> students = null;
		private String tagName;
		private Student stu;
		@Override
		public void characters(char[] ch, int start, int length)
				throws SAXException {
			// TODO Auto-generated method stub
			if(tagName!=null){
				String data = new String(ch,start,length);
				if(tagName.equals("name")){
					stu.setName(data);
				}else if(tagName.equals("sex")){
					stu.setSex(data);
				}else if(tagName.equals("age")){
					stu.setAge(Integer.parseInt(data));
				}
			}
		}

		@Override
		public void endDocument() throws SAXException {
			// TODO Auto-generated method stub
			super.endDocument();
		}

		@Override
		public void endElement(String uri, String qName, String localName)
				throws SAXException {
			// TODO Auto-generated method stub
			if(localName.equals("student")){
				students.add(stu);
				stu = null;
			}
			tagName = null;
		}

		@Override
		public void startDocument() throws SAXException {
			// TODO Auto-generated method stub
			students = new ArrayList<Student>();
		}

		@Override
		public void startElement(String uri, String qName, String localName,
				Attributes attributes) throws SAXException {
			// TODO Auto-generated method stub
			if(localName.equals("student")){
				stu = new Student();
				stu.setId(Integer.parseInt(attributes.getValue("id")));
			}
			tagName = localName;
		}
		
	}
}
