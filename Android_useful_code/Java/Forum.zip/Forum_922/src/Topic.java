
public class Topic extends Tip {
	private int themeId;
	
	public int getThemeId(){
		return themeId;
	}
	public void setThemeId(int themeId){
		this.themeId = themeId;
	} 
	
	private int plateId;
	
	public int getPlateId() {
		return plateId;
	}
	public void setPlateId(int plateId) {
		this.plateId = plateId;
	}
	
	public void showTip(){
		display();
	} 
	
	private void display(){
		System.out.println("----this is in the Topic----");
		System.out.println("themeId:"+themeId);
		System.out.println("plateId:"+plateId);
	}

}
