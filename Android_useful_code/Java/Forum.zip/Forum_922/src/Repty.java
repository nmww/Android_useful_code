
public class Repty extends Tip {
	private int reptyId;
	public void setReptyId(int reptyId){
		this.reptyId = reptyId;
	}
	public int getReptyId(){
		return reptyId;
	}
	
	private int themeId;
	public int getThemeId() {
		return themeId;
	}
	public void setThemeId(int themeId) {
		this.themeId = themeId;
	}
	
	public void showTip(){
		display();
	} 
	
	private void display(){
		System.out.println("----this is in the Repty----");
		System.out.println("reptyId:"+reptyId);
		System.out.println("themeId:"+themeId);
	}

	

}
