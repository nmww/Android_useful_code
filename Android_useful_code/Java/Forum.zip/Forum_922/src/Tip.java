import java.util.Date;
import java.util.Scanner;


public class Tip {
	private String title;  //标题
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getOnTime() {
		return onTime;
	}
	public void setOnTime(String onTime) {
		this.onTime = onTime;
	}
	private String content;//内容
	private String onTime;//发帖时间
	
	public Tip(){
		title = "无参"; //标题
		content = "内容";//内容
		onTime = new Date().toLocaleString();//发帖时间
	}
	public Tip(String title, String content){
		this.title = title;
		this.content = content;
	}
	
	public void inputInfo(){
		input();
	}
	public void showTip(){
		display();
	}
	
	private void inputTitle(){
		Scanner input = new Scanner(System.in);
		title = input.nextLine();
	}
	private void inputContent(){
		Scanner input = new Scanner(System.in);
		content = input.nextLine();
	}
	private void input(){
		System.out.print("input title:");
		inputTitle();
		System.out.print("input content:");
		inputContent();
	}
	private void display(){
		System.out.println("-----TipInfo-----");
		System.out.println("title:"+title);
		System.out.println("content:"+content);
		System.out.println("onTime:"+onTime);
	}
}
