
public class Test {

	/**
	 * @param args
	 * 演示了一个论坛的标题，内容，信息输入显示，信息获取等。
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1.
		/*构造方法new的时候传参*/
//		Tip t = new Tip();
		Tip t = new Tip("title", "content");
//		t.inputInfo();//输入标题信息
		t.showTip();//显示贴子信息
	//2.	
		Board b = new Board();
		b.getBoardInfo();
	//3.	
		User u = new User();
		u.getUserInfo();
	//5.	
		Topic topic = new Topic();
		//topic.inputInfo();
		topic.showTip();//输出主体信息
	//6.
		Repty r = new Repty();
		r.showTip();// 输入主体信息
	}

}
