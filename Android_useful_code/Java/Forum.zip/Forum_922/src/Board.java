
public class Board {
	private double boardId = 1.0;//版块属性
	public double getBoardId() {
		return boardId;
	}

	public void setBoardId(double boardId) {
		this.boardId = boardId;
	}

	public String getBoardTitle() {
		return boardTitle;
	}

	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	private String boardTitle = "Nothing Help Title!";
	private int parentId = 001;//注版块ID
	
	public void getBoardInfo(){
		System.out.println("---------boardId-----------");
		System.out.println("boardId:"+boardId);
		System.out.println("boardTitle:"+boardTitle);
		System.out.println("parentId:"+parentId);
	}
}
