
public class User {
	private int uId = 0;
	private String uName = null;
	private int uPass = 0;
	
	public void getUserInfo(){
		System.out.println("---------uId---------");
		System.out.println("uId:"+uId);
		System.out.println("uName:"+uName);
		System.out.println("uPass:"+uPass);
	}

	public int getuId() {
		return uId;
	}

	public void setuId(int uId) {
		this.uId = uId;
	}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public int getuPass() {
		return uPass;
	}

	public void setuPass(int uPass) {
		this.uPass = uPass;
	}

}
