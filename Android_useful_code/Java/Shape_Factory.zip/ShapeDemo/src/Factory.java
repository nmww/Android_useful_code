
public class Factory {
	public static Shape creat(String s){
		if(s.equals("Rectangco")){
			return new Rectangco(2, 3);
		}else if(s.equals("Cyclo")){
			return new Cyclo(2);
		}
		return null;
	}
}
