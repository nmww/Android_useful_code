
public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Shape s = Factory.creat("Cyclo"); 
		cacl(s);
		show(s);
/*		Cyclo r = new Cyclo(2);
		cacl(r);
		show(r);
*/	}
	
	public static void cacl(Shape c){
		System.out.println(c.calcArea()); 
	}
	public static void show(Shape s){
		s.draw();
	}
}















