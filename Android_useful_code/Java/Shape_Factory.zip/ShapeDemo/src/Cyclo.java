
public class Cyclo extends Shape{
	private int r;
	public Cyclo(int r){
		this.r = r;
	}
	
	/*public int getR() {
		return r;
	}
	public void setR(int r) {
		this.r = r;
	}
*/
	@Override
	public double calcArea() {
		return 3.14*r*r;
	}

	@Override
	public void draw() {
		System.out.println("draw a cyclo"+calcArea());
		
	}

}
