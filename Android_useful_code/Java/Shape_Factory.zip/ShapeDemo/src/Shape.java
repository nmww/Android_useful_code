
public abstract class Shape {
	//private int area;
	public abstract double calcArea();
	public abstract void draw();

}
