package com.zhg.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.zhg.entity.Student;

public class StudentXmlParser {
	public ArrayList<Student> parse(File path) throws  IOException, SAXException, ParserConfigurationException{
		SAXParserFactory factory;
		SAXParser parser;
		StudentHandler sHandler = new StudentHandler();
		
		factory = SAXParserFactory.newInstance();
		parser = factory.newSAXParser();
		parser.parse(path, sHandler);
		
		return sHandler.students;
	}
	
	private class StudentHandler extends DefaultHandler{
		ArrayList<Student> students;
		String tagName;
		Student student;
		@Override
		public void characters(char[] ch, int start, int length)
				throws SAXException {
			// TODO Auto-generated method stub
			if(tagName!=null && student!=null){
				String data = new String(ch,start,length);
				if(tagName.equalsIgnoreCase("name")){
					student.setName(data);
				}else if(tagName.equalsIgnoreCase("sex")){
					student.setSex(data);
				}else if(tagName.equals("age")){
					student.setAge(Integer.parseInt(data));
				}
			}
		}

		@Override
		public void endElement(String uri, String localName, String qName)
				throws SAXException {
			// TODO Auto-generated method stub
			if(localName.equalsIgnoreCase("student")){
				students.add(student);
				student = null;
			}
			tagName = null;
		}

		@Override
		public void startDocument() throws SAXException {
			// TODO Auto-generated method stub
			students = new ArrayList<Student>();
		}

		@Override
		public void startElement(String uri, String localName, String qName,
				Attributes attributes) throws SAXException {
			// TODO Auto-generated method stub
			if(localName.equalsIgnoreCase("student")){
				student = new Student();
				student.setId(Integer.parseInt(attributes.getValue("id")));
			}
			tagName = localName;
		}
		
	}
}
