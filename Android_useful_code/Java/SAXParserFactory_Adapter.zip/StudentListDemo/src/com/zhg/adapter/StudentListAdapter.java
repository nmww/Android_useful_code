package com.zhg.adapter;

import java.util.ArrayList;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.zhg.entity.Student;
import com.zhg.studentlist.R;

public class StudentListAdapter extends BaseAdapter{
	ArrayList<Student> students;
	LayoutInflater inflater;
	
	public StudentListAdapter(Context context,ArrayList<Student> students){
		this.inflater = LayoutInflater.from(context);
		this.students = students;
	}

	public int getCount() {
		// TODO Auto-generated method stub
		return students.size();
	}

	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return students.get(position);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return students.get(position).getId();
	}

	public View getView(int position, View convertView, ViewGroup group) {
		// TODO Auto-generated method stub
		//����item��ͼ
		ViewHolder holder = null;
		if(convertView==null){
			convertView = (View)inflater.inflate(R.layout.stuitem, null);
			holder = new ViewHolder();
			holder.tvId = (TextView)convertView.findViewById(R.id.tvId);
			holder.tvName = (TextView)convertView.findViewById(R.id.tvName);
			holder.tvSex = (TextView)convertView.findViewById(R.id.tvSex);
			holder.tvAge = (TextView)convertView.findViewById(R.id.tvAge);
			convertView.setTag(holder);
		}else{
			holder = (ViewHolder)convertView.getTag();
		}
		//����position��ȡstudent����
		Student stu = students.get(position);
		//��������䵽item��ͼ��
		holder.tvId.setText(String.valueOf(stu.getId()));
		
		holder.tvName.setText(stu.getName());
		
		holder.tvSex.setText(stu.getSex());
		
		holder.tvAge.setText(String.valueOf(stu.getAge()));
		//����ͼ���� 
		return convertView;
	}
	
	private class ViewHolder{
		TextView tvId;
		TextView tvName;
		TextView tvSex;
		TextView tvAge;
	}
}
