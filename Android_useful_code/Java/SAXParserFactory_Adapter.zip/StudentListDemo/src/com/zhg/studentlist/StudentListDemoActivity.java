package com.zhg.studentlist;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.zhg.adapter.StudentListAdapter;
import com.zhg.entity.Student;
import com.zhg.utils.StudentXmlParser;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class StudentListDemoActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        StudentXmlParser parser = new StudentXmlParser();
        File file = new File("/mnt/sdcard/student/student.xml");
        if(!file.exists()){
        	return;
        }
        
        try {
			ArrayList<Student> students = parser.parse(file);
			StudentListAdapter adapter = new StudentListAdapter(this, students);
			ListView lvStudents = (ListView)findViewById(R.id.listStudents);
			lvStudents.setAdapter(adapter);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}