import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class DataOutputTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileOutputStream out = null;
		DataOutputStream dout = null;
		try {
			out = new FileOutputStream("c:\\abc.zhg");
			dout = new DataOutputStream(out);
			
			dout.writeInt(315);
			dout.writeDouble(3.14);
			dout.writeBoolean(false);
			dout.writeUTF("���");
			dout.writeLong(325648);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(dout!=null){dout.close();dout=null;}
				if(out!=null){out.close();out=null;}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
