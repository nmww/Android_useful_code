import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public class BufferdInputTest {
	public static void main(String[] args){
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		
		try {
			fis = new FileInputStream("c:\\abc.txt");
			bis = new BufferedInputStream(fis);
			int len = -1;
			byte[] bytes = new byte[1024];
			while((len=bis.read(bytes))!=-1){
				System.out.println(new String(bytes,0,len));
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(bis!=null){bis.close();bis = null;}
				if(fis!=null){fis.close();fis = null;}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}
}
