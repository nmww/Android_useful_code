import java.io.File;
import java.io.IOException;
import java.util.Date;

public class FileTest {

	private static final boolean File = false;

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File("c:\\abc.txt");
		System.out.println("file �Ƿ���ڣ�" + file.exists());
		if (!file.exists()) /* ����������ļ����½� */{
			try {
				file.createNewFile();
				file.setReadable(true);
				file.setWritable(true);
				file.setReadOnly();
				file.setLastModified(new Date().getTime());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("file �ļ���:" + file.getName());
		System.out.println("·����:" + file.getPath());
		System.out.println("·����:" + file.getParent());
		System.out.println("�Ƿ��ļ�:" + file.isFile());
		System.out.println("�Ƿ��ļ���:" + file.isDirectory());
		System.out.println("����޸�ʱ��:" + file.lastModified());

		System.out.println("=========File dir============");
		File dir = new File("c:\\abc");
		if (!dir.exists()) {
			dir.mkdir();
		} else {
			System.out.println("dir �ļ���:" + dir.getName());
			System.out.println("·����:" + dir.getPath());
			System.out.println("·����:" + dir.getParent());
			System.out.println("�Ƿ��ļ�:" + dir.isFile());
			System.out.println("�Ƿ��ļ���:" + dir.isDirectory());

			file.delete();
			dir.delete();
		}
		System.out.println("=========File a============");
		try {
			File a = new File("c:\\abc\\abc\\abc.txt");
			System.out.println(a.getParentFile().mkdirs());
			System.out.println(a.createNewFile());
			File b = new File("c:\\abc\\bcd\\abc.txt");
			System.out.println(b.getParentFile().mkdirs());
			System.out.println(b.createNewFile());

			// a.delete();
			// b.delete();
			File path = new File("c:\\abc");
			if (path.isFile()) {
				path.delete();
			} else {
//				dir1(path);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

	}
//�ݹ����ɾ������c:\\abcȫ������
	public static void dir1(File path) {
		File[] p = path.listFiles();
		for (File f : p) {
			if (f.isFile()) {
				System.out.println(f.isFile());
				f.delete();
			} else {
				dir1(f);
			}
		}
		path.delete();
	}
}
