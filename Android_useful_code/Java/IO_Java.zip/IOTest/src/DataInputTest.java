import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public class DataInputTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream fis = null;
		DataInputStream dis = null;
		try {
			fis = new FileInputStream("c:\\abc.zhg");;
			dis = new DataInputStream(fis);
			
			int num1 = dis.readInt();
			double d = dis.readDouble();
			boolean b = dis.readBoolean();
			String s = dis.readUTF();
			long l = dis.readLong();
			
			System.out.println(num1+","+d+","+b+","+s+","+l);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				if(dis!=null){dis.close();dis=null;}
				if(fis!=null){fis.close();fis=null;}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}

}
