import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


public class FileInputTest {
	public static void main(String[] args){
		File file =new File( "c:\\abc.txt");
		FileInputStream in = null;
		try {
			in = new FileInputStream(file);
			byte[] bytes = new byte[1024];
			int len = -1;
			while((len = in.read(bytes)) != -1){
				String data = new String(bytes,0,len);
				System.out.println(data);
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				in.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
