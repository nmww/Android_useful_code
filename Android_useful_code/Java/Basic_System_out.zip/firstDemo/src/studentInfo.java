import java.util.Scanner;


public class studentInfo {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("input name");
		String name = input.next();
		System.out.print("input age");
		int age = input.nextInt();
		System.out.print("input birthday month/day");
		String birthday = input.next();
		System.out.println(name + ' ' + birthday + " " + age);
	}
}
