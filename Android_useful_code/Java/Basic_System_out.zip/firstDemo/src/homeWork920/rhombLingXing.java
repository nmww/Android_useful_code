package homeWork920;

public class rhombLingXing {
	public static void main(String[] args) {
		int i, j, k;
		for (i = 1; i <= 7; i++) {
			for (k = 1; k <= 7 - i; k++)
				System.out.print(" ");
			for (j = 1; j <= 2 * i - 1; j++){
				if (j == 1 || j == 2 * i - 1)
				System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
		for (i = 6; i >= 1; i--) {
			for (k = 1; k <= 7 - i; k++)
				System.out.print(" ");
			for (j = 1; j <= 2 * i - 1; j++){
				if (j == 1 || j == 2 * i - 1)
				System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
}
