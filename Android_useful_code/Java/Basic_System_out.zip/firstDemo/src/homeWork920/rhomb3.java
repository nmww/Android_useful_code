package homeWork920;

/**
 * 
 * @author Administrator 并排的三个空心菱形
 */
public class rhomb3 {
	public static void main(String[] args) {
		int i, j, k;
		for (i = 1; i <= 7; i++) {
			for (k = 1; k <= 7 - i; k++)
				System.out.print(" ");
			for (j = 1; j <= 2 * i - 1; j++) {
				// 判断空心
				if (j == 1 || j == 2 * i - 1) {
					System.out.print("*");
				} else
					System.out.print(" ");
				if (j == 2 * i - 1) {
					for (k = 1; k <= 2 * 7 - 2 * i; k++)
						System.out.print(" ");
					for (j = 1; j <= 2 * i - 1; j++) {
						// 判断空心
						if (j == 1 || j == 2 * i - 1) {
							System.out.print("*");
						} else
							System.out.print(" ");
						if (j == 2 * i - 1) {
							for (k = 1; k <= 2 * 7 - 2 * i; k++)
								System.out.print(" ");
							for (j = 1; j <= 2 * i - 1; j++) {
								// 判断空心
								if (j == 1 || j == 2 * i - 1)
									System.out.print("*");
								else
									System.out.print(" ");
							}
						}
					}
				}
			}
			System.out.println();
		}
		/**
		 * 楚河汉界
		 */
		for (i = 6; i >= 1; i--) {
			for (k = 1; k <= 7 - i; k++)
				System.out.print(" ");
			for (j = 1; j <= 2 * i - 1; j++) {
				if (j == 1 || j == 2 * i - 1)
					System.out.print("*");
				else
					System.out.print(" ");
				if (j == 2 * i - 1) {
					for (k = 1; k <= 2 * 7 - 2 * i; k++)
						System.out.print(" ");
					for (j = 1; j <= 2 * i - 1; j++) {
						if (j == 1 || j == 2 * i - 1)
							System.out.print("*");
						else
							System.out.print(" ");
						if (j == 2 * i - 1) {
							for (k = 1; k <= 2 * 7 - 2 * i; k++)
								System.out.print(" ");
							for (j = 1; j <= 2 * i - 1; j++) {
								if (j == 1 || j == 2 * i - 1)
									System.out.print("*");
								else
									System.out.print(" ");
							}

						}
					}

				}
			}
			System.out.println();
		}
	}
}