import java.util.Scanner;

public class Input {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.print("please input name:");
		String name = input.next();
		System.out.print("please input age");
		int age = input.nextInt();
		System.out.print("name:" + name + ',' + "age:" + age);
	}
}
