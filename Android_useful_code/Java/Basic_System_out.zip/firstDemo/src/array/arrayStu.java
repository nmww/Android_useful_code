package array;

import java.util.Arrays;
import java.util.Scanner;

public class arrayStu {
	public static void main(String[] args){
		//int[] score = {70,98,40,34,88}; // 两个一样
		//int[] score = new int[]{70,98,40,34,88};
		int[] score;
		score = new int[5];
		Scanner input = new Scanner(System.in);
		for (int i=0; i<5; i++){
			System.out.print("input"+i+"number");
			score[i] = input.nextInt();
			System.out.println("score["+i+"]"+score[i]+' ');
		}
		Arrays.sort(score);
		for (int i=0; i<5; i++){
			System.out.println(score[i]);
		}
		System.out.println("score[0]"+score[0]);
	}
}
