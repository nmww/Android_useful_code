package array;

import java.util.Arrays;

public class arrayRand {
	public static void main(String[] args){
		int i;
		int[] array;
		array = new int[10];
		for (i=0; i<10; i++){
			array[i] = (int)(Math.random()*10);
		}
		Arrays.sort(array);
		for (i=0; i<10; i++){
			System.out.println("array["+i+']'+array[i]);
		}
	}
}
