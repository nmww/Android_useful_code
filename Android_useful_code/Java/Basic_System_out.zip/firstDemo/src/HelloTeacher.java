public class HelloTeacher {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Teacher!");
		/**
		 *print不带换行 println带换行 
		 */
		System.out.print("Hello Teacher!");
		System.out.println("Hello Teacher!");
	}
}
