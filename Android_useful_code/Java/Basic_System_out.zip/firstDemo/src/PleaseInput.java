import java.util.Scanner;


public class PleaseInput {
	public static void main(String[] args) {
		int liSi = 80;	//学员李四成绩
		boolean isBig;	//声明一个boolean变量
		Scanner input = new Scanner(System.in);
		while(true){
		System.out.print("输入学员张三成绩：");
		int zhangSan = input.nextInt();
		isBig = zhangSan > liSi;
		if (false == isBig) {
		System.out.println("张三成绩比李四高吗？" + isBig);
		break;
		}
		else
		System.out.println("张三成绩比李四高吗？" + isBig);
		}
	}
}
