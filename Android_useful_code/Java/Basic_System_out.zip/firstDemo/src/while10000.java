
public class while10000 {
	public static void main(String[] args){
			int n = 1;
		while (true){
			System.out.println(n + "Yes I can!");
			n++;
			if (n == 10000)
				break;
		}
			System.out.println(n + "Yes I can!");
	}
}
