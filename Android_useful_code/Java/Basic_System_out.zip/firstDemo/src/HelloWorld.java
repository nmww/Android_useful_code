public class HelloWorld {

	/**
	 * @param args
	 * @return
	 * @version 1.0.0.0
	 * @author Administrator
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("HelloWorld!!!");
	}
}