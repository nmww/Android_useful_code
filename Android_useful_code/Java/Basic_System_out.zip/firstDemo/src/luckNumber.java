import java.util.Scanner;

public class luckNumber {
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		while (true){
		System.out.print("please input luckly number 0-9:");
		int number = input.nextInt();
		int luck =(int)(Math.random()*10);
			if (number<0 || number>9)
				System.out.println("please input 0-9");
			else{	
				if (number == luck){
					System.out.println("congratulation,you win 500.");
					break;
				} else
					System.out.println("try next time.");
				System.out.println("user number" + number 
						+ '\n' + "luckly number" + luck);
			}
		}
	}
}
