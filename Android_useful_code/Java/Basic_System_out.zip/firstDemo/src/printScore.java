import java.util.Scanner;


public class printScore {
	public static void main(String[] args){
	Scanner input = new Scanner(System.in);
	System.out.print("input socre");
	int score = input.nextInt();
		switch(score){
		case 90:
			System.out.println(score + "good!");
			break;
		default:
			System.out.println(score + "bad!");
			break;
		}
		if (score >= 90)
			System.out.println(score + "best");
		else if (score>=80 && score<90)
			System.out.println(score + "better");
		else if (score < 80) 
			System.out.println(score + "good");
		else 
			System.out.println("over");
	}
}

