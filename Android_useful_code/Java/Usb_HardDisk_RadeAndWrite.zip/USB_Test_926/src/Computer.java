public abstract class Computer {
	public int a;

	public abstract String Read();

	public abstract void Write();
}
