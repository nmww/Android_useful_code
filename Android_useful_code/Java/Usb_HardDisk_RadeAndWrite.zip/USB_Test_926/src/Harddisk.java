public class Harddisk extends Computer {

	private String r;
	//private String w;

	public Harddisk(String r, String w) {
		super();
		this.r = r;
		//this.w = w;
	}

	@Override
	public String Read() {
		// TODO Auto-generated method stub
		return r;
	}

	@Override
	public void Write() {
		// TODO Auto-generated method stub
		System.out.println("write disk");

	}

}
