public class Usb extends Computer {

	private String r;
//	private String w;

	public Usb(String r, String w) {
		super();
		this.r = r;
	//	this.w = w;
	}

	@Override
	public String Read() {
		return r;
	}

	@Override
	public void Write() {
		System.out.println("write usb");
	}
}
