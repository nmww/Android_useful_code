public class R_W_Factory {
	public static Computer ites(String s) {
		if (s.equals("Usb")) {
			return new Usb("read usb someth.", "write anything to usb.");
		} else if (s.equals("Harddisk")) {
			return new Harddisk("read Hard", "write Hard");
		}
		return null;
	}
}
