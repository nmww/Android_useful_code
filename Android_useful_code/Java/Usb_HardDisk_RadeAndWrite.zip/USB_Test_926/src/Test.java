public class Test {

	/**
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Computer p = R_W_Factory.ites("Usb");
		Computer p = R_W_Factory.ites("Harddisk");
		read(p);
		write(p);
	}

	static void read(Computer s) {
		if (null != s)
			System.out.println(s.Read());
	}

	static void write(Computer w) {
		if (null != w)
			w.Write();
	}
}
