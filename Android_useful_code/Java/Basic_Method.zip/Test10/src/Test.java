import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;


public class Test {
	public static void main(String[] args){
//		System.out.println(Math.abs(-3));
//		System.out.println(Math.ceil(3.14));
//		System.out.println(Math.floor(3.64));
//		System.out.println(Math.round(3.64));
//		System.out.println(Math.random());
//		Random rand = new Random();
//		System.out.println(rand.nextInt(100));
//		Date date = new Date();
//		System.out.println(date);
//		
//		Calendar c = Calendar.getInstance();
//		c.get(Calendar.DAY_OF_MONTH);
//		c.get(Calendar.DAY_OF_WEEK);
//		System.out.println(c.get(Calendar.MONTH));
//		c.get(Calendar.YEAR);
//		
//		c.set(Calendar.YEAR,1999);
//		c.set(1999,9, 28);
//		c.set(1999,9,28,12,55);
//		c.set(1999,9,28,12, 55,32);
//		
//		Date date = c.getTime();
//		SimpleDateFormat formater = new SimpleDateFormat("yyyy��MM��dd�� hh:mm:ss");
//		System.out.println(formater.format(date));
		
		//��װ��
//		Integer i = new Integer(20);
//		byte b = i.byteValue();
//		int c = i.intValue();
//		double d = i.doubleValue();
//		
//		int  x  = Integer.parseInt("12");
//		int y = new Integer("12");
//		
//		Integer ttt = Integer.valueOf(12);
//		Integer xxx = Integer.valueOf("12");
		
//		String[]  x = {"abc","eds","cbd","axe"};
//		Arrays.sort(x);
//		for(String s : x){
//			System.out.println(s);
//		}
		
//		Date date = new Date();
//		
//		Student stu2 = new Student(1,"zs",19);
//		Student stu1 = new Student(1,"zs",19);
//		if(stu1==stu2){
//			System.out.println("stu1==stu2");
//		}else{
//			System.out.println("stu1!=stu2");
//		}
//		
//		if(stu1.equals(stu2)){
//			System.out.println("stu1==stu2");
//		}else{
//			System.out.println("stu1!=stu2");
//		}
		
		Student[] s = new Student[6];
		int len = s.length;
		for(int i=0;i<len;i++){
			s[i] = new Student(i,"zs"+i,(int)(Math.random()*37)+18);
		}
		
		s[3].setName( "wulaoqi");
		Arrays.sort(s,new StudentByAge());
		for(Student stu : s){
			System.out.println(stu);
		}
	}
}
