package com.zhg.demo;

import com.zhg.entity.Computer;
import com.zhg.entity.HardDiskStorage;

public class Demo {
	public static void main(String[] args){
		Computer c = new Computer();
		//IMobile disk = new IMobile();
		HardDiskStorage disk = new HardDiskStorage();
		/*SuperStorage ss = new SuperStorage();
		SuperStorageAdapter adapter = new SuperStorageAdapter();
		adapter.setSuperStorage(ss);
		c.setStorage(adapter);
		*/
		c.setStorage(disk);
		
		c.read();
		c.write();
	}

}
