package com.zhg.entity;

public class Computer {
	private IMobile storage;

	public IMobile getStorage() {
		return storage;
	}
	public void setStorage(IMobile storage) {
		this.storage = storage;
	}
	public void read(){
		storage.read();
	}
	public void write(){
		storage.write();
	}
}
