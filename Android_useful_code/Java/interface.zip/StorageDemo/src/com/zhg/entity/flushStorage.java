package com.zhg.entity;

public class flushStorage implements IMobile{

	@Override
	public void read() {
		// TODO Auto-generated method stub
		System.out.println("reading from flushstorage...");

	}

	@Override
	public void write() {
		// TODO Auto-generated method stub
		System.out.println("writing to flushstorage...");

	}

}
