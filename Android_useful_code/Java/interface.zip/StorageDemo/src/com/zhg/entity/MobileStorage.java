package com.zhg.entity;

public abstract class MobileStorage{
	public abstract void read();
	public abstract void write();

}
