package com.zhg.entity;

public class Mp3Player implements IMobile{

	@Override
	public void read() {
		// TODO Auto-generated method stub
		System.out.println("reading from mp3storage...");
	}

	@Override
	public void write() {
		// TODO Auto-generated method stub
		System.out.println("reading from mp3storage...");
	}

}
