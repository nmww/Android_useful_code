package com.zhg.entity;

public interface IMobile {
	void read();
	void write();
}
