package com.zhg.entity;

public class SuperStorage {
	public void rd(){
		System.out.println("reading from superstorage...");
	}
	public void wt(){
		System.out.println("writing to superstorage...");
	}

}
