package com.zhg.entity;

public class SuperStorageAdapter implements IMobile{
	private SuperStorage superStorage;
	public SuperStorage getSuperStorage(){
		return superStorage;
	}
	public void setSuperStorage(SuperStorage superStorage){
		this.superStorage = superStorage;
	}

	@Override
	public void read() {
		// TODO Auto-generated method stub
		superStorage.rd();
	}
	@Override
	public void write() {
		// TODO Auto-generated method stub
		superStorage.wt();
		
	}
	

}
