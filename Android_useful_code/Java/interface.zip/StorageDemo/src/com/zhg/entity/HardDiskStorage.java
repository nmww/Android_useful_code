package com.zhg.entity;

public class HardDiskStorage implements IMobile{

//	public static HardDiskStorage disk;

	@Override
	public void read() {
		System.out.println("reading from diskstorage...");

	}

	@Override
	public void write() {
		// TODO Auto-generated method stub
		System.out.println("reading from diskstorage...");

	}

}
