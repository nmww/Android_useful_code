import java.util.Scanner;


public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		System.out.println("���������(1900֮��)");
		int year = input.nextInt();
		System.out.println("�������·�");
		int month = input.nextInt();
		
		MyCalendar mc = new MyCalendar(year, month);
		//mc.year = 0;
		//mc.month = -18;
		
		mc.dispaly();
	}

}
