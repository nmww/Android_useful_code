package com.gongsi.resolver;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
/* 1.Users.java右键单击，选择EXPORT...导出
 * 2.导出为java- JAR file包，保存到ResolverActivity需要访问数据库的文件程序workspaces中
 * 3.在Resolver中多出了一个Users.jar文件，右键打击选择Build Path 添加到资源中即可。
 * */
import com.gongsi.providercontent.Users;

public class ResolverActivityActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        ContentResolver cr = getContentResolver(); 
        ContentValues values = new ContentValues();
        values.put(Users.Columns.NAME, "zhangsan");
        values.put(Users.Columns.PHONE, "12312312321");
        cr.insert(Users.CONTENT_URI, values);
        
        Cursor cursor = cr.query(Users.CONTENT_URI, null, null, null, null);
        while(cursor.moveToNext()){
        	Log.i("info", Users.Columns.ID + ":" + cursor.getString(cursor.getColumnIndex(Users.Columns.ID)));
        	Log.i("info", Users.Columns.NAME + ":" + cursor.getString(cursor.getColumnIndex(Users.Columns.NAME)));
        	Log.i("info", Users.Columns.PHONE+ ":" + cursor.getString(cursor.getColumnIndex(Users.Columns.PHONE)));
        }
        cursor.close();
        
    }
}