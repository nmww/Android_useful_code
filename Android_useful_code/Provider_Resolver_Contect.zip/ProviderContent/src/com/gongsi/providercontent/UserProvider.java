package com.gongsi.providercontent;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.text.Selection;
import android.widget.SlidingDrawer;
/* 1.Users.java右键单击，选择EXPORT...导出
 * 2.导出为java- JAR file包，保存到ResolverActivity需要访问数据库的文件程序workspaces中
 * 3.在Resolver中多出了一个Users.jar文件，右键打击选择Build Path 添加到资源中即可。
 * 
 * 需要在manifest中注册
 * <application android:icon="@drawable/icon" android:label="@string/app_name">
		<provider
			android:name=".UserProvider"
			android:authorities="com.gongsi.providercontent"
		 >
		</provider>
    </application>
 * */
public class UserProvider extends ContentProvider {
	private DBOpenHelper helper;
	private SQLiteDatabase db;

	private Context context;

	private static final int USERS = 1;
	private static final int USER = 2;
	private static UriMatcher matcher;
	static {
		matcher = new UriMatcher(UriMatcher.NO_MATCH);
		matcher.addURI(Users.AUTHORITY, Users.MULTIPLE_PATH, USERS);
		matcher.addURI(Users.AUTHORITY, Users.SINGLE_PATH, USER);
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		context = getContext();
		helper = new DBOpenHelper(context);
		if (helper == null)
			return false;
		else
			return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		String where = "";
		switch (matcher.match(uri)) {
		case USERS:
			where = selection;
			break;
		case USER:
			where = Users.Columns.ID + "=" + uri.getLastPathSegment();
			if(selection!=null){
				where += "and(" + selection + ")";
			}
			break;

		default:
			throw new IllegalArgumentException("unknow uri" + uri);
		}
		if(projection==null){
			projection = new String[]{Users.Columns.ID, Users.Columns.NAME, Users.Columns.PHONE};	
		}
		db = helper.getReadableDatabase();
		Cursor cursor = db.query("usertbl", projection, where, selectionArgs, null, null, sortOrder);
		return cursor;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		switch (matcher.match(uri)) {
		case USERS:
			return Users.CONTENT_TYPE;
		case USER:
			return Users.CONTENT_ITEM_TYPE;
		default:
			throw new IllegalArgumentException("unknow uri" + uri);
		}
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		Uri url = null;
		if(matcher.match(uri) != USERS){
			throw new IllegalArgumentException("unknow uri" + uri);
		}
		db = helper.getWritableDatabase();
		long rowId = db.insert("usertbl", null, values);
		if(rowId>0){
			url = ContentUris.withAppendedId(Users.CONTENT_URI, rowId);
			context.getContentResolver().notifyChange(uri, null);
		}
		db.close();
		return url;
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		String where = "";
		switch (matcher.match(uri)) {
		case USERS:
			where = selection;
			break;
		case USER:
			where = Users.Columns.ID + "=" + uri.getLastPathSegment();
			if(selection!=null){
				where += "and (" + selection + ")";
			}
			
			break;

		default:
			throw new IllegalArgumentException("unknow uri" + uri);
		}
		db = helper.getReadableDatabase();
		int count = db.delete("usertbl", where, selectionArgs);
		db.close();
		context.getContentResolver().notifyChange(uri, null);
		return count;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		String where = "";
		switch (matcher.match(uri)) {
		case USERS:
			where = selection;
			break;
		case USER:
			where = Users.Columns.ID + "=" + uri.getLastPathSegment();
			if(selection!=null){
				where += "and (" + selection + ")";
			}

		default:
			throw new IllegalArgumentException("unknow uri" + uri);
		}
		db = helper.getWritableDatabase();
		int count = db.update("usertbl", values, where, selectionArgs);
		context.getContentResolver().notifyChange(uri, null);
		return count;
	}

}
