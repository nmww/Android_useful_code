package com.gongsi.providercontent;

import android.net.Uri;
/* 1.定义了其他程序访问该数据库资源，需要使用的权限路径，根目录和单个目录，还有类型。
 * 2.定义数据结构中的成员，隐藏真实的列名
 * */
public class Users {
	public static final String AUTHORITY = "com.gongsi.providercontent";
	public static final String MULTIPLE_PATH = "user";
	public static final String SINGLE_PATH = "user/#";
	public static final Uri CONTENT_URI = Uri.parse("content://"+AUTHORITY+"/"+MULTIPLE_PATH); 
	public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.gongsi.provider";
	public static final String CONTENT_ITEM_TYPE ="vnd.android.cursor.item/vnd.gongsi.provider";
	
	public static class Columns{
		public static final String ID = "_id";
		public static final String NAME = "uname";
		public static final String PHONE = "pNumber";
	}
}
