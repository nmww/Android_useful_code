package com.zhg.demo;

import android.app.Activity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TimePicker;
import android.widget.ToggleButton;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Demo1Activity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        RadioGroup rg = (RadioGroup)findViewById(R.id.radioGroup);
        rg.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			
			public void onCheckedChanged(RadioGroup radiogroup, int id) {
				// TODO Auto-generated method stub
				RadioButton rdoChoice = (RadioButton)findViewById(id);
				Toast.makeText(Demo1Activity.this, rdoChoice.getText(), Toast.LENGTH_LONG).show();
			}
		});
        
        CheckBox chkOk = (CheckBox)findViewById(R.id.chkOk);
        chkOk.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener(){

			public void onCheckedChanged(CompoundButton v, boolean isChecked) {
				// TODO Auto-generated method stub
				Toast.makeText(Demo1Activity.this, isChecked+"", Toast.LENGTH_LONG).show();
			}
        	
        });
        
        final TextView tv1 = (TextView)findViewById(R.id.content);
        SeekBar seekBar = (SeekBar)findViewById(R.id.seekBar);
        
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				// TODO Auto-generated method stub
				tv1.setText(String.valueOf(progress));
				
			}

			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				Toast.makeText(Demo1Activity.this,"��ʼ�϶�", Toast.LENGTH_LONG).show();
			}

			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				Toast.makeText(Demo1Activity.this,"�����϶�", Toast.LENGTH_LONG).show();
			}
        	
        });
        
        final RatingBar ratinBar = (RatingBar)findViewById(R.id.ratinBar);
        ratinBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener(){

			public void onRatingChanged(RatingBar arg0, float rating, boolean arg2) {
				// TODO Auto-generated method stub
				int nums = ratinBar.getNumStars();
				Toast.makeText(Demo1Activity.this,String.valueOf(rating)+"/"+nums, Toast.LENGTH_LONG).show();
			}
        	
        });
        
        ToggleButton toggle = (ToggleButton)findViewById(R.id.toggleButton);
        toggle.setOnCheckedChangeListener(new ToggleButton.OnCheckedChangeListener(){

			public void onCheckedChanged(CompoundButton v, boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked){
					Toast.makeText(Demo1Activity.this,"��", Toast.LENGTH_LONG).show();
				}else{
					Toast.makeText(Demo1Activity.this,"��", Toast.LENGTH_LONG).show();
				}
			}
        	
        });
        DatePicker picker1 = (DatePicker)findViewById(R.id.datePicker);
        picker1.init(2010, 9, 12, new DatePicker.OnDateChangedListener() {
			
			public void onDateChanged(DatePicker arg0, int year, int month, int day) {
				// TODO Auto-generated method stub
				Toast.makeText(Demo1Activity.this,year+","+month+","+day, Toast.LENGTH_LONG).show();
			}
		});
        TimePicker picker2 = (TimePicker)findViewById(R.id.timePicker);
        picker2.setIs24HourView(true);
        picker2.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
			
			public void onTimeChanged(TimePicker v, int hours, int minutes) {
				// TODO Auto-generated method stub
				Toast.makeText(Demo1Activity.this,hours+":"+minutes, Toast.LENGTH_LONG).show();
			}
		});
     }
}