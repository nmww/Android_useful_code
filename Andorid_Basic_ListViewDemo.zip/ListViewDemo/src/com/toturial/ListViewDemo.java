package com.toturial;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ListViewDemo extends Activity {
    /** Called when the activity is first created. */
	private Button button1;
	private Button button2;
	private Button button3;
	private Button button4;
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //ActivityList1
        button1 = (Button)findViewById(R.id.Button01);
        button1.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(ListViewDemo.this,ActivityList1.class);
				startActivity(intent);
			}
        	
        });
        
      //ActivityList2
        button2 = (Button)findViewById(R.id.Button02);
        button2.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(ListViewDemo.this,ActivityList2.class);
				startActivity(intent);
			}
        	
        });
        
        //ActivityList3
        button3 = (Button)findViewById(R.id.Button03);
        button3.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(ListViewDemo.this,ActivityList3.class);
				startActivity(intent);
			}
        	
        });
        
        //ActivityList4
        button4 = (Button)findViewById(R.id.Button04);
        button4.setOnClickListener(new Button.OnClickListener(){

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(ListViewDemo.this,ActivityList4.class);
				startActivity(intent);
			}
        	
        });
    }
}