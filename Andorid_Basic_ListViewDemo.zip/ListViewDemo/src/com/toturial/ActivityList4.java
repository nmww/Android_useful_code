package com.toturial;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class ActivityList4 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setTitle("ActivityList4");
		
		
		ListView listView = new ListView(this);
		String []data = getResources().getStringArray(R.array.list_data);
		ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,data);
		listView.setAdapter(adapter);
		
		setContentView(listView);
		
		listView.setOnItemSelectedListener(new ListView.OnItemSelectedListener(){

			@Override
			public void onItemSelected(AdapterView<?> parentView, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				Toast.makeText(ActivityList4.this, "ѡ��"+parentView.getItemAtPosition(position).toString(), Toast.LENGTH_SHORT).show();
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
			
		});
	}

}
